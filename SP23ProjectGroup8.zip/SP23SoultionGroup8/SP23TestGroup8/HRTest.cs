﻿using Moq;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.Controllers;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;
using SP23MvcGroup8.View_Models;
using Microsoft.CodeAnalysis.Elfie.Serialization;
using System.ComponentModel.DataAnnotations;

namespace SP23TestGroup8
{
    public class HRTest
    {
        // create mock repos 

        private Mock<IHumanResourceRepo> mockHRRepo;
        private Mock<IMajorRepo> mockMajorRepo;
        private Mock<IStudentRepo> mockStudentRepo;
        private Mock<IInternshipRepo> mockInternshipRepo;
        private Mock<ICertificateRepo> mockCertificateRepo;
        private Mock<IJobHistoryRepo> mockJobHistoryRepo;
        private Mock<IProjectRepo> mockProjectRepo;
        private Mock<IStudentInternshipRepo> mockStudentInternshipRepo;
        private Mock<IStudentProjectRepo> mockStudentProjectRepo;
        private Mock<IStudentCertificateRepo> mockStudentCertificateRepo;
        private Mock<IStudentJobRepo> mockStudentJobRepo;
        
        private HRController controller;


        public HRTest()
        {
            this.mockMajorRepo = new Mock<IMajorRepo>();
            this.mockHRRepo = new Mock<IHumanResourceRepo>();
            this.mockStudentRepo = new Mock<IStudentRepo>();
            this.mockInternshipRepo = new Mock<IInternshipRepo>();
            this.mockCertificateRepo = new Mock<ICertificateRepo>();
            this.mockJobHistoryRepo = new Mock<IJobHistoryRepo>();
            this.mockProjectRepo = new Mock<IProjectRepo>();
            this.mockStudentInternshipRepo = new Mock<IStudentInternshipRepo>();
            this.mockStudentProjectRepo = new Mock<IStudentProjectRepo>();
            this.mockStudentCertificateRepo = new Mock<IStudentCertificateRepo>();
            this.mockStudentJobRepo = new Mock<IStudentJobRepo>();

            this.controller = new HRController(this.mockHRRepo.Object, this.mockMajorRepo.Object, this.mockStudentRepo.Object, this.mockCertificateRepo.Object,this.mockInternshipRepo.Object, this.mockJobHistoryRepo.Object, this.mockProjectRepo.Object, this.mockStudentInternshipRepo.Object, this.mockStudentProjectRepo.Object, this.mockStudentCertificateRepo.Object, this.mockStudentJobRepo.Object);




        }
        // create test for adding student major 

        [Fact]
        public void ShouldListOfAllStudents()
        {
            //AAA Approac

            //Arrange 
            List<Student> Allstudents = CreateMockData();
            this.mockHRRepo.Setup(m => m.ListAllStudents()).Returns(Allstudents);
            int expected = Allstudents.Count;

            //Act
            ViewResult result = this.controller.ListAllStudents() as ViewResult;

            List<Student> resultsStudents = result.Model as List<Student>;
            //Assert

            Assert.Equal(expected, resultsStudents.Count);

        }

        [Fact]
        public void ShouldListOfAllStudentsById()
        {
            //AAA Approac

            //Arrange 
            List<Student> Allstudents = CreateMockData();
            this.mockHRRepo.Setup(m => m.ListAllStudents()).Returns(Allstudents);
            int studentId = Allstudents.First().StudentID;
            int expected = Allstudents.Count;

            //Act
            ViewResult result = this.controller.ListAllStudents() as ViewResult;

            List<Student> resultsStudents = result.Model as List<Student>;
            //Assert

            Assert.Equal(expected, resultsStudents.Count);
            Assert.Equal(studentId, resultsStudents.FirstOrDefault().StudentID);

        }


        // Acting on a list all students?

        [Fact]
        public void ShouldAddStudentMajor()
        {
            //AAA Approac

            //Arrange 
            List<Student> Allstudents = CreateMockData();
            this.mockHRRepo.Setup(m => m.ListAllStudents()).Returns(Allstudents);
            int majorId = Allstudents.FirstOrDefault().StudentMajors.First().MajorID;
            int expected = Allstudents.Count();
            

            //Act
            ViewResult result = this.controller.ListAllStudents() as ViewResult;
            List<Student> resultsStudents = result.Model as List<Student>;
            //Assert

            Assert.Equal(expected, resultsStudents.Count);
            Assert.Equal(majorId, resultsStudents.FirstOrDefault().StudentMajors.First().MajorID);


        }


        // Dont need this right now
        [Fact]
        public void ShouldAddStudentIntern()
        {
            //AAA Approac

            //Arrange 
            List<Student> Allstudents = CreateMockData();
            this.mockHRRepo.Setup(m => m.ListAllStudents()).Returns(Allstudents);
            int internId = Allstudents.FirstOrDefault().StudentInterships.First().InternshipID;
            int expected = Allstudents.Count();

            //Act
            ViewResult result = this.controller.ListAllStudents() as ViewResult;
            List<Student> resultsStudents = result.Model as List<Student>;
            //Assert

            Assert.Equal(expected, resultsStudents.Count);
            Assert.Equal(internId, resultsStudents.FirstOrDefault().StudentInterships.First().InternshipID);


        }

        [Fact] // NEED TO FIX THIS , Not correct
        public void ShouldAddMajor()
        {

            //Arrange
            Major major = null;
            MajorViewModel viewModel = new MajorViewModel();
            viewModel.MajorName = "Geology";
            this.mockMajorRepo.Setup(m => m.AddMajor(It.IsAny<Major>())).Returns(1).Callback<Major>(m => major = m);
            this.mockMajorRepo.Setup(m => m.GetAllMajors()).Returns(new List<Major>());
            this.mockHRRepo.Setup(m => m.ListAllStudents()).Returns(new List<Student>());

            //Act
            this.controller.AddMajor(viewModel);

            //Assert
            this.mockMajorRepo.Verify(m => m.AddMajor(It.IsAny<Major>()), Times.Once());
            Assert.Equal(viewModel.MajorName, major.MajorName);
        }

        [Fact]
        public void ShouldNotAddMajor()
        {
            //Arrange
            MajorViewModel viewModel = new MajorViewModel();
            viewModel.MajorName = null;
            string expectedError = "The MajorName field is required.";
            var results = new List<ValidationResult>();

            //Act
            bool isValid = Validator.TryValidateObject(viewModel, new ValidationContext(viewModel), results);


            //Assert
            Assert.False(isValid);
            Assert.Equal(expectedError, results[0].ErrorMessage);
        }





        // now create mock data for adding major to student
        public List<Student> CreateMockData() 
        {

            List<Student> students = new List<Student>();

            Student student = new Student("Bob", "Gnole", "3045578764", "Test.Bob@test.com", "Test.Bob", 1);
            student.Id = "100";
            Major major = new Major("Finance");
            StudentMajor studentMajor = new StudentMajor("100", 1);
            studentMajor.Major = major;
            Internship internship = new Internship("Google");
            StudentIntership studentInternship = new StudentIntership("100", 1);
            student.StudentInterships.Add(studentInternship);
            student.StudentMajors.Add(studentMajor);
            students.Add(student);

            student = new Student("Lex", "Hine", "3045578764", "Test.Bob@test.com", "Test.Bob", 2);
            student.Id = "101";
            major = new Major("Economics");
            studentMajor = new StudentMajor("101", 2);
            studentMajor.Major = major;
            internship = new Internship("Apple");
            studentInternship = new StudentIntership("101", 2);
            student.StudentInterships.Add(studentInternship);
            student.StudentMajors.Add(studentMajor);
            students.Add(student);

            student = new Student("Tim", "Belt", "3045578764", "Test.Bob@test.com", "Test.Bob", 3);
            student.Id = "102";
            major = new Major("MIS");
            studentMajor = new StudentMajor("102", 3);
            studentMajor.Major = major;
            internship = new Internship("Walmart");
            studentInternship = new StudentIntership("102", 3);
            student.StudentInterships.Add(studentInternship);
            student.StudentMajors.Add(studentMajor);
            students.Add(student);

            student = new Student("Andrew", "Black", "3045578764", "Test.Bob@test.com", "Test.Bob", 4);
            student.Id = "103";
            studentMajor = new StudentMajor("103", 3);
            studentMajor.Major = major;
            student.StudentMajors.Add(studentMajor);
            students.Add(student);


            return students;
        }




    }
}
