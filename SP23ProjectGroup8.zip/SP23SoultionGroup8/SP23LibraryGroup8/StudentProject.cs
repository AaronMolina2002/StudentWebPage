﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class StudentProject
    {
        [Key]
        public int StudentProjectID { get; set; }

        public string StudentID { get; set; }

        [ForeignKey("StudentID")]
        public Student Student { get; set; }


        public int PersonalProjectID { get; set; }

        [ForeignKey("PersonalProjectID")]
        public PersonalProject PersonalProject { get; set; }

        public StudentProject(string studentId, int personalProjectId) 
        
        
        {

            StudentID = studentId;
            PersonalProjectID= personalProjectId;
        
        }

        public StudentProject() { }
    }
}