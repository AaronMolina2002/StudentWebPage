﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class PersonalProject
    {
        [Key]
        public int PersonalProjectID { get; set; }

        // public bool ProjectCompleted { get; set; }

        public string ProjectType { get; set; }

        //make an IF statement to see if the project is completed, what it's for


        public List<StudentProject> StudentProjects { get; set; } = new List<StudentProject>(); 




        public PersonalProject(string projectType) 
        {
           // PersonalProjectID = peronalProjectID;
           // ProjectCompleted = projectCompleted;
            ProjectType = projectType;
            
            
        }

        public PersonalProject()
        
        {
         
        }

        
        
    }
}