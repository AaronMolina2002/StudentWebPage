﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SP23LibraryGroup8
{
    public class AppUser : IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string FullName { get { return FirstName + " " + LastName; } }

        public AppUser(string firstname, string lastname, string phonenumber, string email, string password)
        {
            FirstName = firstname;
            LastName = lastname;
            this.PhoneNumber = phonenumber;
            this.Email = email;
            this.UserName = email;
            PasswordHasher<AppUser> passwordhasher = new PasswordHasher<AppUser>();
            this.PasswordHash = passwordhasher.HashPassword(this, password);
        }

            public AppUser() { }
    }
}
