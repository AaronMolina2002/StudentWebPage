﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class Certificate
    {
        [Key]
        public int CertificateID { get; set; }
        public string CertificateType { get; set; }
      //  public DateTime DateCompleted { get; set; } TAKE TO TUTOR


        public List<StudentCertificate> StudentCertificates { get; set; } = new List<StudentCertificate>();






        public Certificate(string certificateType) //DateTime dateCompleted
        
        {
            // certificateID = CertificateID;
            // dateCompleted = DateCompleted;
            CertificateType = certificateType;
           
           


        }   


        public Certificate() 
        {
           

        }   
    }
}