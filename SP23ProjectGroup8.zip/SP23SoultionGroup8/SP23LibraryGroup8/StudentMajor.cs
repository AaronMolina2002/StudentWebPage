﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class StudentMajor
    {

        [Key]
        public int StudentMajorID { get; set; }

        public string StudentID { get; set; }

        [ForeignKey("StudentID")]
        public Student Student { get; set; }

        public int MajorID { get; set; }

        [ForeignKey("MajorID")]
        public Major Major { get; set; }


        public StudentMajor(string studentID, int majorID)
        {
            StudentID = studentID;
            MajorID = majorID;
        }

        public StudentMajor() { }




    }
}