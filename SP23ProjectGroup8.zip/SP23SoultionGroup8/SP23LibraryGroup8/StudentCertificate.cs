﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class StudentCertificate
    {
        [Key]
        public int StudentCertificateID { get; set; }


        public string StudentID { get; set; }

        [ForeignKey("StudentID")]
        public Student Student { get; set; }


        public int CertificateID { get; set; }

        [ForeignKey("CertificateID")]
        public Certificate Certificate { get; set; }






        public StudentCertificate(string studentId, int certificateId) 
        
        {
            StudentID = studentId;
            CertificateID = certificateId;
        }

        public StudentCertificate() { }
    }
}