﻿namespace SP23LibraryGroup8
{
    public class HR : AppUser
    {
        // public int StudentID { get; set; }  StudentID will be given an ID 

       



        public HR(string firstname, string lastname, string phonenumber, string email, string password)
            : base(firstname, lastname, phonenumber, email, password)
        {
           
        }

        public HR() { }
    }
}