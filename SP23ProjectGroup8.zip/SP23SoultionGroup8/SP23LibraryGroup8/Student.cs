﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class Student : AppUser
    {


        // public int StudentSchoolID { get; set; }



        public int StudentID { get; set; }


        public List<StudentIntership> StudentInterships { get; set; } = new List<StudentIntership>(); // student can be part of multiple internships

        public List<StudentProject> StudentProjects { get; set; } = new List<StudentProject>();// student can be part of multiple projects

        public List<StudentCertificate> StudentCertificates { get; set; } = new List<StudentCertificate>();// student can have  multiple certificates

        public List<StudentJobHistory> StudentJobHistories { get; set; } = new List<StudentJobHistory>(); // student can have many past jobs

        public List<StudentMajor> StudentMajors { get; set; } = new List<StudentMajor>(); // student can have one major



        public Student(string firstName, string lastName, string email, string phone, string password, int studentID) : base(firstName, lastName, email, phone, password)
        {
            StudentID = studentID;
        }



        public Student()
        {

        }

    }
}