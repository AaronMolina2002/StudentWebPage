﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class StudentIntership
    {
        [Key]
        public int StudentIntershipID { get; set; }


        public string StudentID { get; set; }

        [ForeignKey("StudentID")]            //FK StudentID and InternshipID go into contructor
        public Student Student { get; set; }



        public int InternshipID { get;set; }

        [ForeignKey("InternshipID")]
        public Internship Internship { get; set; }






        public StudentIntership(string studentId, int internshipId) 
        
        { 
            StudentID = studentId;
            InternshipID= internshipId;
        
        }

        public StudentIntership() { }
    }


}