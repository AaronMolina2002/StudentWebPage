﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class Internship
    {
        [Key]
        public int InternshipID { get; set; }
        
        public string TypeofInternship { get; set; }



       public List<StudentIntership> StudentInterships { get; set; } // internship can have multiple students keepin track of students





        public Internship( string typeInternship ) 
        {
            
           
            TypeofInternship = typeInternship;
            
            StudentInterships = new List<StudentIntership>();

        }

        public Internship() 
        {
            StudentInterships = new List<StudentIntership>();
        }


        
       
    }
}