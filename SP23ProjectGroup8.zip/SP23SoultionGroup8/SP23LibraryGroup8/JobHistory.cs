﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class JobHistory
    {
        [Key]
        public int JobID { get; set; }
        public DateTime JobApplied { get; set; }
        public string JobName { get; set; }
        public double JobSalary { get; set; }


        public List<StudentJobHistory> StudentJobHistories { get; set; }= new List<StudentJobHistory>();


        public JobHistory( DateTime jobDateApplied, string jobName, double jobSalary)
        {
           
            JobApplied = jobDateApplied;
            JobName = jobName;
            JobSalary = jobSalary;
            
            


        }

        public JobHistory() 
        
        {
           
        }

        
       
    }
}