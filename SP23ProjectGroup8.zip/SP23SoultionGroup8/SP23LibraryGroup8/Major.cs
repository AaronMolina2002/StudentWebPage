﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryGroup8
{
    public class Major
    {
        [Key]
        public int MajorID { get; set; }   

        public string MajorName { get; set;}

       

        public List<StudentMajor> StudentMajors { get; set; } = new List<StudentMajor>();


       

        public Major(string majorName) 
        {

          

            MajorName = majorName;

         

        
        
        }

        public Major() { }


    }
}