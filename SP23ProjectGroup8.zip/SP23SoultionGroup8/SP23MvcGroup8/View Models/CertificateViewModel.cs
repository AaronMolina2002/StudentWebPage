﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class CertificateViewModel
    {

        public int CertificateID { get; set; }
        [Required]

        public string CertificateType { get; set; }

    }
}
