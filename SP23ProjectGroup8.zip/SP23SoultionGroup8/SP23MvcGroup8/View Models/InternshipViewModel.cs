﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class InternshipViewModel
    {
        
        public int InternshipID { get; set; }

        [Required]
        public string TypeofInternship { get; set; }

    }
}
