﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.View_Models
{
    public class AddStudentViewModel
    {
      
      

        public List<int> MajorIDs { get; set; }

      
        public string StudentID { get; set; }




    }
}
