﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class ProjectViewModel
    {

        public int PersonalProjectID { get; set; }

        [Required]
        public string ProjectType { get; set; }

    }
}
