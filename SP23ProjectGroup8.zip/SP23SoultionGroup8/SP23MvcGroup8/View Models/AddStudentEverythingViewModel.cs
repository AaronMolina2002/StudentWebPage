﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.View_Models
{
    public class AddStudentEverythingViewModel
    {
        public List<int> CertificateIDs { get; set; }

        public List<int> ProjectIDs { get; set; }

        public List<int> JobHistoryIDs { get; set; }

        public List<int> InternshipIDs { get; set; }



        public string StudentID { get; set; }



    }
}
