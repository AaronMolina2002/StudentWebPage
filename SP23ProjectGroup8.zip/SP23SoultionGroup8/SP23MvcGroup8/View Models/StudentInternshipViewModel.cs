﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class StudentInternshipViewModel
    {
      
        public int StudentIntershipID { get; set; }

        [Required]
        public string StudentID { get; set; }

        [Required]
        public int InternshipID { get; set; }
    }
}
