﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class StudentCertificateViewModel
    {


        public int StudentCertificateID { get; set; }

        [Required]
        public string StudentID { get; set; }

        [Required]
        public int CertificateID { get; set; }

        
    }
}
