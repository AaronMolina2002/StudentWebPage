﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class JobHistoryViewModle
    {
        [Required]
        public int JobID { get; set; }
        [Required]

        public DateTime JobApplied { get; set; }
        [Required]

        public string JobName { get; set; }
        [Required]

        public double JobSalary { get; set; }

    }
}
