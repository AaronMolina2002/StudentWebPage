﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class MajorViewModel
    {
        //[Required]
        public int MajorID { get; set; }

        [Required]
        public string MajorName { get; set; }



    }
}
