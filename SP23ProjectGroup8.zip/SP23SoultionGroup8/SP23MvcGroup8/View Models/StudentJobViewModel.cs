﻿using System.ComponentModel.DataAnnotations;

namespace SP23MvcGroup8.View_Models
{
    public class StudentJobViewModel
    {
        public int StudentJobHistoryID { get; set; }

        [Required]
        public string StudentID { get; set; }

        [Required]
        public int JobHistoryID { get; set; }
    }
}
