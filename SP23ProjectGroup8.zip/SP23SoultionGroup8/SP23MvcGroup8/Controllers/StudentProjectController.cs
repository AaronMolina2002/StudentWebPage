﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;
using System.Data;

namespace SP23MvcGroup8.Controllers
{
    public class StudentProjectController : Controller
    {

        private IStudentProjectRepo iStudentProjectRepo;
        private IProjectRepo iProjectRepo;
        private IStudentRepo iStudentRepo;

        public StudentProjectController(IStudentProjectRepo studentProjectRepo, IProjectRepo projectRepo, IStudentRepo studentRepo)
                {

                    this.iStudentProjectRepo = studentProjectRepo;
                    this.iProjectRepo = projectRepo;
            this.iStudentRepo = studentRepo;
                }

        public IActionResult ListStudentProjects(string studentID)
        {
            List<StudentProject> allProjects = this.iStudentProjectRepo.ListStudentProjects(studentID);

            return View(allProjects);
        }


        

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddProject(string studentID)
        {
            StudentProjectViewModel studentProjectpViewModel = new StudentProjectViewModel();

            studentProjectpViewModel.StudentID = studentID;

            CreatDropdownList();

            return View(studentProjectpViewModel);
        }


        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddProject(StudentProjectViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                StudentProject studentProject = new StudentProject(viewModel.StudentID, viewModel.ProjectID);

                this.iStudentProjectRepo.AddProject(studentProject);

                return RedirectToAction("ShowStudentDetails", "HR", new { studentID = viewModel.StudentID });

            }

            else
            {
                CreatDropdownList();

                return View(viewModel);

            }

        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteProject(int studentProjectID)
        {
            StudentProject studentProject = this.iStudentProjectRepo.FindStudentProject(studentProjectID);

            StudentProjectViewModel viewModel = new StudentProjectViewModel();

            viewModel.StudentID = studentProject.StudentID;
            viewModel.StudentProjetID = studentProject.StudentProjectID;
            viewModel.ProjectID = studentProject.PersonalProjectID;

            ViewData["AllStudentProjects"] = new SelectList(this.iProjectRepo.ListProjects(), "PersonalProjectID", "ProjectType");

            List<Student> Allstudents = new List<Student>();
            Allstudents.Add(this.iStudentRepo.FindStudent(viewModel.StudentID));

            ViewData["AllStudents"] = new SelectList(Allstudents, "Id", "FullName");




            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteProject(StudentProjectViewModel viewModel)
        {
            StudentProject studentProject = this.iStudentProjectRepo.FindStudentProject(viewModel.StudentProjetID);

            this.iStudentProjectRepo.DeleteProject(studentProject);
            return RedirectToAction("ShowStudentDetails", "HR", new { studentID = viewModel.StudentID });
        }


        public void CreatDropdownList()
        {

            ViewData["AllProjects"] = new SelectList(this.iProjectRepo.ListProjects(), "PersonalProjectID", "ProjectType");

        }


    }
}
