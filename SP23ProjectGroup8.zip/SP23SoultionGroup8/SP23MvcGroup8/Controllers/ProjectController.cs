﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;
using System.Data;

namespace SP23MvcGroup8.Controllers
{
    public class ProjectController : Controller
    {
        private IProjectRepo iProjectRepo;


        public ProjectController(IProjectRepo projectRepo)
        {

            this.iProjectRepo = projectRepo;

        }

        public IActionResult ListProjects()
        {
            List<PersonalProject> allProjects = this.iProjectRepo.ListProjects();
            return View(allProjects);
        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditProject(int projectID)
        {

            return View(this.iProjectRepo.FindProject(projectID));
        }


        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditProject(PersonalProject project)
        {
            if (ModelState.IsValid)
            {
                this.iProjectRepo.EditProject(project);

                return RedirectToAction("ListProjects");

            }

            else
            {
                return View(project);
            }

        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteProject(int ProjectID)
        {
            PersonalProject project = this.iProjectRepo.FindProject(ProjectID);

            ProjectViewModel viewModel = new ProjectViewModel();
            viewModel.ProjectType = project.ProjectType;

            return View(viewModel);
        }

        //Talk to professor about null value for project name. 
        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteProject(ProjectViewModel viewModel)
        {
            PersonalProject project = this.iProjectRepo.FindProject(viewModel.PersonalProjectID);

            if (ModelState.IsValid)
            {
                this.iProjectRepo.DeleteProject(project);

                return RedirectToAction("ListProjects");
            }
            else
            {
                return View(viewModel);
            }
        }
    }
}

