﻿//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using SP23LibraryGroup8;
//using SP23MvcGroup8.Models;
//using System.Data;

//namespace SP23MvcGroup8.Controllers
//{
//    public class MajorController : Controller
//    {
//        private IMajorRepo iMajorRepo;

//        public MajorController (IMajorRepo majorRepo)
//        {
//            this.iMajorRepo = majorRepo;
//        }

//        public IActionResult ListMajors()
//        {
//            List<Major> allMajors = this.iMajorRepo.GetAllMajors();
//            return View(allMajors);
//        }

//        [HttpGet]
//        [Authorize(Roles = "Human Resources")]
//        public IActionResult EditJob(int jobID)
//        {

//            return View(this.iJobHistoryRepo.FindJobHistory(jobID));


//        }
//        [HttpPost]
//        [Authorize(Roles = "Human Resources")]
//        public IActionResult EditJob(JobHistory jobHistory)
//        {
//            if (ModelState.IsValid)
//            {
//                this.iJobHistoryRepo.EditJob(jobHistory);

//                return RedirectToAction("ListJobs");

//            }

//            else
//            {
//                return View(jobHistory);
//            }

//        }
//    }
//}
