﻿using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using Newtonsoft.Json;
using System.Diagnostics;
using static SP23MvcGroup8.Models.Chart;

namespace SP23MvcGroup8.Controllers
{
    public class HomeController : Controller
    {
        //private IInternshipRepo iInternshipRepo;
        private IHumanResourceRepo iHumanResourceRepo;
        private readonly ILogger<HomeController> _logger;


        public HomeController(ILogger<HomeController> logger, IHumanResourceRepo humanResourceRepo )
        {
            _logger = logger;
            this.iHumanResourceRepo = humanResourceRepo;
        }

        public IActionResult Index()
        {
            List<DataPoint> dataPoints = new List<DataPoint>();
            List<Student> allStudents = this.iHumanResourceRepo.ListAllStudents().OrderByDescending(s => s.StudentInterships.Count).Take(4).ToList();

            foreach(Student student in allStudents) 
            {
                dataPoints.Add(new DataPoint(student.FullName, student.StudentInterships.Count, student.StudentID));
            
            }

            ViewData["Internships"] = JsonConvert.SerializeObject(dataPoints);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}