﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;

namespace SP23MvcGroup8.Controllers
{
    public class StudentJobController : Controller
    {
        private IStudentJobRepo iStudentJobRepo;
        private IJobHistoryRepo iJobHistoryRepo;
        private IStudentRepo iStudentRepo;

         public StudentJobController(IStudentJobRepo studentJobRepo, IJobHistoryRepo jobRepo, IStudentRepo studentRepo)
                {

                    this.iStudentJobRepo = studentJobRepo;
                    this.iJobHistoryRepo = jobRepo;
            this.iStudentRepo = studentRepo;
                }

        public IActionResult ListStudentJobs(string studentID)
        {
            List<StudentJobHistory> allJobs = this.iStudentJobRepo.ListStudentJobs(studentID);

            return View(allJobs);
        }


       

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddJob(string studentID)
        {
            StudentJobViewModel viewModel = new StudentJobViewModel();

            viewModel.StudentID = studentID;

            CreatDropdownList();

            return View(viewModel);
        }


        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddJob(StudentJobViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                StudentJobHistory studentJobHistory = new StudentJobHistory(viewModel.StudentID, viewModel.JobHistoryID);

                this.iStudentJobRepo.AddJob(studentJobHistory);

                return RedirectToAction("ShowStudentDetails", "HR", new { studentID = viewModel.StudentID });

            }

            else
            {
                CreatDropdownList();

                return View(viewModel);

            }

        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteJob(int studentJobID)
        {
            StudentJobHistory studentJob = this.iStudentJobRepo.FindStudentJob(studentJobID);

            StudentJobViewModel viewModel = new StudentJobViewModel();

            
            viewModel.StudentJobHistoryID = studentJob.StudentJobHistoryID;
            viewModel.JobHistoryID = studentJob.JobHistoryID;
            viewModel.StudentID = studentJob.StudentID;
            ViewData["AllStudentJobs"] = new SelectList(this.iJobHistoryRepo.ListJobs(), "JobHistoryID", "JobName");

            List<Student> Allstudents = new List<Student>();
            Allstudents.Add(this.iStudentRepo.FindStudent(viewModel.StudentID));

            ViewData["AllStudents"] = new SelectList(Allstudents, "Id", "FullName");




            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteJob(StudentJobViewModel viewModel)
        {
            StudentJobHistory studentJob = this.iStudentJobRepo.FindStudentJob(viewModel.StudentJobHistoryID);

            this.iStudentJobRepo.DeleteJob(studentJob);
            return RedirectToAction("ShowStudentDetails");
        }


        public void CreatDropdownList()
        {

            ViewData["AllJobs"] = new SelectList(this.iJobHistoryRepo.ListJobs(), "JobID", "JobName");

        }


    }
}
