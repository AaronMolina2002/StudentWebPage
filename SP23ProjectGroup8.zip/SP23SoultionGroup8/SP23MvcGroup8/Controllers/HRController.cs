﻿using Humanizer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Elfie.Serialization;
using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;
using System.Security.Claims;

namespace SP23MvcGroup8.Controllers
{
    public class HRController : Controller
    {
        private IHumanResourceRepo iHumanResourceRepo;
        private IMajorRepo iMajorRepo;
        private IStudentRepo istudentRepo;
        private ICertificateRepo iCertificateRepo;
        private IInternshipRepo iInternshipRepo;
        private IJobHistoryRepo iJobHistoryRepo;
        private IProjectRepo iProjectRepo;
        private IStudentInternshipRepo iStudentInternshipRepo;
        private IStudentProjectRepo iStudentProjectRepo;
        private IStudentCertificateRepo iStudentCertificateRepo;
        private IStudentJobRepo iStudentJobRepo;
        //  private ApplicationDbContext _database;

        public HRController(IHumanResourceRepo hrRepo, IMajorRepo majorRepo, IStudentRepo studentRepo, ICertificateRepo certificateRepo, IInternshipRepo internshipRepo, IJobHistoryRepo jobHistoryRepo, IProjectRepo project, IStudentInternshipRepo studentInternship, IStudentProjectRepo iStudentProjectRepo, IStudentCertificateRepo studentCertificateRepo, IStudentJobRepo studentJobRepo)
        {
            this.iHumanResourceRepo = hrRepo;
            this.iMajorRepo = majorRepo;
            this.istudentRepo = studentRepo;
            this.iCertificateRepo = certificateRepo;
            this.iInternshipRepo = internshipRepo;
            this.iJobHistoryRepo = jobHistoryRepo;
            this.iProjectRepo = project;
            this.iStudentInternshipRepo = studentInternship;
            this.iStudentProjectRepo = iStudentProjectRepo;
            this.iStudentCertificateRepo = studentCertificateRepo;
            this.iStudentJobRepo = studentJobRepo;
        }

        public IActionResult ListAllStudents(string? studentID = null)
        {
            

            List<Student> AllStudents = this.iHumanResourceRepo.ListAllStudents();

           

            return View(AllStudents);
        }

        public IActionResult ShowStudentDetails(string studentId)
        {

            return View(this.istudentRepo.FindStudent(studentId));
        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddMajor()
        {

            CreateDropDownList();



            return View();
        }


    

           [HttpPost]
           [Authorize(Roles = "Human Resources")]
           public IActionResult AddMajor(MajorViewModel viewModel)
           {
                List<Major> majors = this.iMajorRepo.GetAllMajors().Where(m => m.MajorName == viewModel.MajorName).ToList();

                if (majors.Any())
                {
                    ModelState.AddModelError("Duplicate!", "This Major already exists!");

                }

                if (ModelState.IsValid)
                {
                    Major major = new Major(viewModel.MajorName);
                    this.iMajorRepo.AddMajor(major);
                    return RedirectToAction("ListAllStudents");
                }

                else
                {
                    return View(viewModel);
                }
           }


        public void CreateDropDownList()
        {
            ViewData["AllMajors"] = new SelectList(this.iMajorRepo.GetAllMajors(), "MajorID", "MajorName");
            ViewData["AllStudents"] = new SelectList(this.iHumanResourceRepo.ListAllStudents(), "Id", "FirstName", "LastName");
        }

    }
}
