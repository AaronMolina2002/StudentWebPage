﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;
using System.Data;

namespace SP23MvcGroup8.Controllers
{
    public class CertificateController : Controller
    {

        private ICertificateRepo iCertificateRepo;


        public CertificateController(ICertificateRepo certificateRepo)
        {

            this.iCertificateRepo = certificateRepo;

        }

        public IActionResult ListCertificates()
        {
            List<Certificate> allCertificates = this.iCertificateRepo.ListCertificates();

            return View(allCertificates);
        }
        [HttpGet]
        public IActionResult AddCertificate()
        {
            CertificateViewModel viewmodel = new CertificateViewModel();

            return View(viewmodel);
        }

        [HttpPost]
        public IActionResult AddCertificate(CertificateViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                Certificate certificate = new Certificate(viewModel.CertificateType);
                this.iCertificateRepo.AddCertificate(certificate);
                return RedirectToAction("ListCertificates");
            }
            else
                return View(viewModel);
        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditCertificate(int CertificateID)
        {

            return View(this.iCertificateRepo.FindCertificate(CertificateID));


        }
        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditCertificate(Certificate certificate)
        {
            if (ModelState.IsValid)
            {
                this.iCertificateRepo.EditCertificate(certificate);

                return RedirectToAction("ListCertificates");

            }

            else
            {
                return View(certificate);
            }

        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteCertificate(int CertificateID)
        {
            Certificate certificate = this.iCertificateRepo.FindCertificate(CertificateID);

            CertificateViewModel viewModel = new CertificateViewModel();
            viewModel.CertificateType = certificate.CertificateType;

            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteCertificate(CertificateViewModel viewModel)
        {
            Certificate certificate = this.iCertificateRepo.FindCertificate(viewModel.CertificateID);

            if (ModelState.IsValid)
            {
                this.iCertificateRepo.DeleteCertificate(certificate);

                return RedirectToAction("ListCertificates");
            }
            else
            {
                return View(viewModel);
            }
        }

    }
}
