﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;
using SP23MvcGroup8.View_Models;
using System.Data;

namespace SP23MvcGroup8.Controllers
{
    public class StudentController : Controller
    {

        private ApplicationDbContext _database;

        public StudentController(ApplicationDbContext database)
        {

           this._database = database;
        }

        public IActionResult ListAllStudentsResults()
        {
                List<Student> AllStudents = _database.Student.Include(s => s.StudentInterships).ThenInclude(si => si.Internship).
                    Include(s => s.StudentJobHistories).ThenInclude(s => s.JobHistory).
                    Include(s => s.StudentProjects).ThenInclude(s => s.PersonalProject).
                    Include(s => s.StudentCertificates).ThenInclude(s => s.Certificate).
                    Include(s => s.StudentMajors).ThenInclude(s => s.Major).ToList();

                return View(AllStudents);   

            
        }


        [HttpGet]
        [Authorize(Roles = "Student")]
        public IActionResult AddStudentEverything()
        {

            CreateDropDownList();



            return View();
        }


        [HttpPost]
        [Authorize(Roles = "Student")]
        public IActionResult AddStudentEverything(AddStudentEverythingViewModel viewModel)
        {


            if (viewModel.StudentID == null)
            {
                ModelState.AddModelError("Invalid selection", "Need to select Student");

            }

            if (viewModel.ProjectIDs == null)
            {
                ModelState.AddModelError("Invalid selection", "Need to select Project");

            }

            if (viewModel.InternshipIDs == null)
            {
                ModelState.AddModelError("Invalid selection", "Need to select Intern");

            }

            if (viewModel.JobHistoryIDs == null)
            {
                ModelState.AddModelError("Invalid selection", "Need to select Job"); 

            }

            if (viewModel.CertificateIDs == null)
            {
                ModelState.AddModelError("Invalid selection", "Need to select Certificates");

            }

            if (ModelState.IsValid)
            {





                if (viewModel.ProjectIDs != null)
                {
                    foreach (int eachProjectID in viewModel.ProjectIDs)
                    {


                        StudentProject studentProject = new StudentProject(viewModel.StudentID, eachProjectID);
                        _database.StudentProject.Add(studentProject);
                        _database.SaveChanges();
                    }

                   

                }

               

                if (viewModel.InternshipIDs != null)
                {
                    foreach (int eachInternID in viewModel.InternshipIDs)
                    {


                        StudentIntership studentIntern = new StudentIntership(viewModel.StudentID, eachInternID);
                        _database.StudentIntership.Add(studentIntern);
                        _database.SaveChanges();
                    }

                }

                if (viewModel.JobHistoryIDs != null)
                {
                    foreach (int eachJobID in viewModel.JobHistoryIDs)
                    {


                        StudentJobHistory studentJobHistory = new StudentJobHistory(viewModel.StudentID, eachJobID);
                        _database.StudentJobHistory.Add(studentJobHistory);
                        _database.SaveChanges();
                    }

                }

                if (viewModel.CertificateIDs != null)
                {
                    foreach (int eachCertID in viewModel.CertificateIDs)
                    {


                        StudentCertificate studentCertificate = new StudentCertificate(viewModel.StudentID, eachCertID);
                        _database.StudentCertificate.Add(studentCertificate);
                        _database.SaveChanges();
                    }

                }



                return RedirectToAction("ListAllStudents");
            }



            else
            {
                CreateDropDownList();
                return View(viewModel);



            }





        }



        public void CreateDropDownList()
        {

            ViewData["AllInterns"] = new SelectList(_database.Internship.ToList(), "InternshipID", "TypeofInternship");

            ViewData["AllStudents"] = new SelectList(_database.Student.ToList(), "Id", "FirstName", "LastName");

            ViewData["AllCertificates"] = new SelectList(_database.Certificate.ToList(), "CertificateID", "CertificateType");

            ViewData["AllJobHistorie"] = new SelectList(_database.JobHistory.ToList(), "JobID", "JobName");

            ViewData["AllProjects"] = new SelectList(_database.PersonalProject.ToList(), "PersonalProjectID", "ProjectType");



        }






    }
}
