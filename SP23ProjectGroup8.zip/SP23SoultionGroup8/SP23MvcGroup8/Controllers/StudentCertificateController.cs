﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;

namespace SP23MvcGroup8.Controllers
{
    public class StudentCertificateController : Controller
    {

        private  IStudentCertificateRepo iStudentCertificateRepo;
        private ICertificateRepo certificateRepo;
        private IStudentRepo iStudentRepo;


        public StudentCertificateController(IStudentCertificateRepo studentCertificateRepo, ICertificateRepo certificate, IStudentRepo iStudentRepo)
        {

            this.iStudentCertificateRepo = studentCertificateRepo;
            this.certificateRepo = certificate;
            this.iStudentRepo = iStudentRepo;
        }





        public IActionResult ListStudentInternships(string studentID)
        {


            List<StudentCertificate> allCerts = this.iStudentCertificateRepo.ListStudentCertificates(studentID);

            return View(allCerts);

        }


        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddCert(string studentID)
        {
            StudentCertificateViewModel viewModel = new StudentCertificateViewModel();

            viewModel.StudentID = studentID;

            CreatDropdownList();

            return View(viewModel);
        }


        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult AddCert(StudentCertificateViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                StudentCertificate studentCert = new StudentCertificate(viewModel.StudentID, viewModel.CertificateID);

                this.iStudentCertificateRepo.Add(studentCert);



                return RedirectToAction("ShowStudentDetails", "HR", new { studentID = viewModel.StudentID });

            }

            else
            {
                CreatDropdownList();

                return View(viewModel);

            }

        }


        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteCert(int studentCertID)
        {
            StudentCertificate studentCertificate = this.iStudentCertificateRepo.FindStudentCertificate(studentCertID);

            StudentCertificateViewModel viewModel = new StudentCertificateViewModel();

            //viewModel.StudentID = studentIntership.StudentID;
            //viewModel.StudentIntershipID = studentIntership.StudentIntershipID;
            //viewModel.InternshipID = studentIntership.InternshipID;

            ViewData["AllStudentCerts"] = new SelectList(this.certificateRepo.ListCertificates(), "CertificateID", "CertificateType");

            List<Student> Allstudents = new List<Student>();
            Allstudents.Add(this.iStudentRepo.FindStudent(viewModel.StudentID));

            ViewData["AllStudents"] = new SelectList(Allstudents, "Id", "FullName");




            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteCert(StudentCertificateViewModel viewModel)
        {
            StudentCertificate studentCertificate = this.iStudentCertificateRepo.FindStudentCertificate(viewModel.StudentCertificateID);

            this.iStudentCertificateRepo.Delete(studentCertificate);
            return RedirectToAction("ShowStudentDetails", "HR", new { studentID = viewModel.StudentID });
        }


        public void CreatDropdownList()
        {


            ViewData["AllCerts"] = new SelectList(this.certificateRepo.ListCertificates(), "CertificateID", "CertificateType");

        }

    }
}
