﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;
using System.Data;

namespace SP23MvcGroup8.Controllers
{
    public class JobHistoryController : Controller
    {
        private IJobHistoryRepo iJobHistoryRepo;


        public JobHistoryController(IJobHistoryRepo jobHistoryRepo)
        {

            this.iJobHistoryRepo = jobHistoryRepo;

        }

        public IActionResult ListJobs()
        {
            List<JobHistory> allJobs = this.iJobHistoryRepo.ListJobs();
            return View(allJobs);
        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditJob(int jobID)
        {

            return View(this.iJobHistoryRepo.FindJobHistory(jobID));


        }
        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditJob(JobHistory jobHistory)
        {
            if (ModelState.IsValid)
            {
                this.iJobHistoryRepo.EditJob(jobHistory);

                return RedirectToAction("ListJobs");

            }

            else
            {
                return View(jobHistory);
            }

        }


        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteJobHistory(int JobID)
        {
            JobHistory jobHistory = this.iJobHistoryRepo.FindJobHistory(JobID);

            JobHistoryViewModle viewModel = new JobHistoryViewModle();
            viewModel.JobName = jobHistory.JobName;

            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteJobHistory(JobHistoryViewModle viewModel)
        {
            JobHistory jobHistory = this.iJobHistoryRepo.FindJobHistory(viewModel.JobID);

            if (ModelState.IsValid)
            {
                this.iJobHistoryRepo.DeleteJob(jobHistory);

                return RedirectToAction("ListJobs");
            }
            else
            {
                return View(viewModel);
            }
        }
    }
}
