﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;

namespace SP23MvcGroup8.Controllers
{
    public class StudentInternshipController : Controller
    {

        private IStudentInternshipRepo iStudentInternshipRepo;
        private IInternshipRepo internshipRepo;
        private IStudentRepo istudentRepo;
       

        public StudentInternshipController(IStudentInternshipRepo studentInternshipRepo, IInternshipRepo internship, IStudentRepo studentRepo)
        {

            this.iStudentInternshipRepo = studentInternshipRepo;
            this.internshipRepo = internship;
            this.istudentRepo = studentRepo;
            
        }

        



        public IActionResult ListStudentInternships(string studentID)
        {


            List<StudentIntership> allInternship = this.iStudentInternshipRepo.ListStudentInternships(studentID);

            return View(allInternship);

        }

       

      

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult Delete(int studentInternshipID)
        {
            StudentIntership studentIntership = this.iStudentInternshipRepo.FindStudentInternship(studentInternshipID);

            StudentInternshipViewModel viewModel = new StudentInternshipViewModel();

            viewModel.StudentID = studentIntership.StudentID;
            viewModel.StudentIntershipID = studentIntership.StudentIntershipID;
            viewModel.InternshipID = studentIntership.InternshipID;

            ViewData["AllStudentInternships"] = new SelectList(this.internshipRepo.ListInternships(), "InternshipID", "TypeofInternship");

            List<Student> Allstudents = new List<Student>();
            Allstudents.Add(this.istudentRepo.FindStudent(viewModel.StudentID));

            ViewData["AllStudents"] = new SelectList(Allstudents, "Id", "FullName");




            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult Delete(StudentInternshipViewModel viewModel)
        {
            StudentIntership studentIntership = this.iStudentInternshipRepo.FindStudentInternship(viewModel.StudentIntershipID);

            this.iStudentInternshipRepo.Delete(studentIntership);
            return RedirectToAction("ShowStudentDetails", "HR", new { studentID = viewModel.StudentID });
        }



        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult Add(string studentID)
        {
            StudentInternshipViewModel studentInternshipViewModel = new StudentInternshipViewModel();

            studentInternshipViewModel.StudentID = studentID;

            CreatDropdownList();

            return View(studentInternshipViewModel);
        }


        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult Add(StudentInternshipViewModel viewModel)
        {

            List<StudentIntership> studentIntern = this.iStudentInternshipRepo.ListStudentInternships(viewModel.StudentID).Where(s => s.InternshipID == viewModel.InternshipID).ToList();
            
            if(studentIntern.Any()) {

                ModelState.AddModelError("Dupe", "This can not be added because it DOOOPPPPED ");
            
            }

            if (ModelState.IsValid)
            {
                StudentIntership studentIntership = new StudentIntership(viewModel.StudentID, viewModel.InternshipID);

                this.iStudentInternshipRepo.Add(studentIntership);



                return RedirectToAction("ShowStudentDetails", "HR", new {studentID = viewModel.StudentID});

            }

            else
            {
                CreatDropdownList();

                return View(viewModel);

            }

        }


        public void CreatDropdownList()
        {


            ViewData["AllInternships"] = new SelectList(this.internshipRepo.ListInternships(), "InternshipID", "TypeofInternship");

        }


    }

}
