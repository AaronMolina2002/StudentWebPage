﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SP23LibraryGroup8;
using SP23MvcGroup8.Models;
using SP23MvcGroup8.View_Models;
using System.Data;

namespace SP23MvcGroup8.Controllers
{
    public class InternshipController : Controller
    {

        private IInternshipRepo iInternshipRepo;
        private IStudentRepo iStudentRepo;

        public InternshipController(IInternshipRepo internshipRepo, IStudentRepo studentRepo)
        {

            this.iInternshipRepo = internshipRepo;
            this.iStudentRepo = studentRepo;

        }

        public IActionResult ListInternships()
        {
            List<Internship> allInternships = this.iInternshipRepo.ListInternships();
            return View(allInternships);
        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditInternship(int InternshipID)
        {

            return View(this.iInternshipRepo.FindInternship(InternshipID));


        }
        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult EditInternship(Internship internship)
        {
            if (ModelState.IsValid)
            {
                this.iInternshipRepo.EditInternship(internship);

                return RedirectToAction("ListInternships");

            }

            else
            {
                return View(internship);
            }

        }

        [HttpGet]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteInternship(int InternshipID)
        {
            Internship internship = this.iInternshipRepo.FindInternship(InternshipID);

            InternshipViewModel viewModel = new InternshipViewModel();
            viewModel.TypeofInternship = internship.TypeofInternship;

            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Human Resources")]
        public IActionResult DeleteInternship(InternshipViewModel viewModel)
        {
            Internship internship = this.iInternshipRepo.FindInternship(viewModel.InternshipID);

            if(ModelState.IsValid)
            {
                this.iInternshipRepo.DeleteInternship(internship);

                return RedirectToAction("ListInternships");
            }
            else
            {
                return View(viewModel);
            }
        }


    }
}
