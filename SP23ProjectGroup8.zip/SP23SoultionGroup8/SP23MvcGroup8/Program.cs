using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;
using SP23MvcGroup8.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<AppUser>(options => options.SignIn.RequireConfirmedAccount = false)// change to false for now
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();
builder.Services.AddControllersWithViews();

// builder.Services.AddTransient<IApplicationUserRepo,  ApplicationUserRepo>();
// Make sure to add a transit to use the correct interface / repo
builder.Services.AddTransient<IHumanResourceRepo, HumanResourceRepo>();
builder.Services.AddTransient<IMajorRepo, MajorRepo>();
builder.Services.AddTransient<IInternshipRepo, InternshipRepo>();
builder.Services.AddTransient<IProjectRepo, ProjectRepo>();
builder.Services.AddTransient<IJobHistoryRepo, JobHistoryRepo>();
builder.Services.AddTransient<ICertificateRepo, CertificateRepo>();
builder.Services.AddTransient<IStudentRepo, StudentRepo>();
builder.Services.AddTransient<IStudentInternshipRepo, StudentInternshipRepo>();
builder.Services.AddTransient<IStudentProjectRepo, StudentProjectRepo>();
builder.Services.AddTransient<IStudentJobRepo, StudentJobRepo>();
builder.Services.AddTransient<IStudentCertificateRepo, StudentCertificateRepo>();




var app = builder.Build();

//After app is built call initial databse

using (var scope = app.Services.CreateScope())
{
    // 3 Services: Access Database, Create roles, Create Users

    var services = scope.ServiceProvider;

    try
    {
        InitialDatabase.SeedDatabase(services);
    }
    catch(Exception serviceExpectation)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(serviceExpectation, "Error occured while populating database"); // need help
    }


}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();
