﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;


namespace SP23MvcGroup8.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<AppUser> AppUser { get; set; } // table
        public DbSet<Student> Student { get; set; } // table 

        public DbSet<HR> HR { get; set; }

        public DbSet<Internship> Internship { get; set; } // table

        public DbSet<Certificate> Certificate { get; set; } // table

        public DbSet<JobHistory> JobHistory { get; set; } // table

        public DbSet<PersonalProject> PersonalProject { get; set; } // table

        public DbSet<Major> Major { get; set; } // table

        public DbSet<StudentCertificate> StudentCertificate { get; set; } 

        public DbSet<StudentIntership> StudentIntership { get; set; }

        public DbSet<StudentJobHistory> StudentJobHistory { get; set; }

        public DbSet<StudentProject> StudentProject { get; set; }

        public DbSet<StudentMajor> StudentMajor { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}