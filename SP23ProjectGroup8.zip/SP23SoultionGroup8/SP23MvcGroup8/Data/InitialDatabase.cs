﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Identity.Client;
using SP23LibraryGroup8;
using static System.Net.Mime.MediaTypeNames;

namespace SP23MvcGroup8.Data
{
    public class InitialDatabase
    {
        public static void SeedDatabase( IServiceProvider services)
        {

            //1. Database service
            ApplicationDbContext database = services.GetRequiredService<ApplicationDbContext>();


            //2. Roles Service
            RoleManager<IdentityRole> rolemManager = services.GetRequiredService<RoleManager<IdentityRole>>();


            //3. User Service
            UserManager<AppUser> userManager = services.GetRequiredService<UserManager<AppUser>>();



            //CREATING Roles for App Users

            string administratorRole = "Student";
            string HRRole = "Human Resources";

            if (!database.Roles.Any())
            {
                IdentityRole role = new IdentityRole(HRRole);
                rolemManager.CreateAsync(role).Wait();


                role = new IdentityRole(administratorRole);
                rolemManager.CreateAsync(role).Wait();
            }




            // CREATING Students and Human Resources Employees ADD PARENT
            if (!database.AppUser.Any())
            {

                //HR
                HR HR = new HR("Test", "HR1", "3040000001", "Test.HR1@test.com", "Test.HR1");
                userManager.CreateAsync(HR).Wait();
                userManager.AddToRoleAsync(HR,HRRole).Wait();


                //Admins

                AppUser appUser = new AppUser("Test", "Student", "3040000002", "Test.Student1@test.com", "Test.Student1");
                userManager.CreateAsync(appUser).Wait();
                userManager.AddToRoleAsync(appUser, administratorRole).Wait();

            }




            //DATA FOR CLASSES

            if (!database.Student.Any())
            {
                Student student = new Student("Bob", "Gnole", "3045578764", "Test.Bob@test.com", "Test.Bob", 1);
                database.Student.Add(student);
                database.SaveChanges();

                student = new Student("Rob", "Kole", "3040000005", "Test.Rob@test.com", "Test.Rob", 2);
                database.Student.Add(student);
                database.SaveChanges();

                student = new Student("Jimmy", "Poole", "3045578767", "Test.Jimmy@test.com", "Test.Jimmy", 3);
                database.Student.Add(student);
                database.SaveChanges();

                student = new Student("Tim", "Jimmerson", "3045578767", "Test.Tim@test.com", "Test.Tim", 4);
                database.Student.Add(student);
                database.SaveChanges();

                student = new Student("David", "Pumpkins", "3045578767", "Test.David@test.com", "Test.David", 5);
                database.Student.Add(student);
                database.SaveChanges();

                student = new Student("Andy", "Dick", "3045578767", "Test.Andy@test.com", "Test.Andy", 6);
                database.Student.Add(student);
                database.SaveChanges();

                student = new Student("Napoleon", "Blownaparte", "3045578767", "Test.Napoleon@test.com", "Test.Napoleon", 7);
                database.Student.Add(student);
                database.SaveChanges();
            }

            if (!database.Internship.Any()) 
            
            {

                Internship internship = new Internship( "Manufacturing Engineer");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship  = new Internship( "Product Management");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Data Science");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Finance");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Product Marketing");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Advertising ");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Sales");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Product Management");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("IT Network Operations");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Global Market Analyst");
                database.Internship.Add(internship);
                database.SaveChanges();

                internship = new Internship("Human Resources");
                database.Internship.Add(internship);
                database.SaveChanges();

            }
          

            if(!database.Certificate.Any()) 
            
            {
                Certificate certificate= new Certificate( "ITIL");
                database.Certificate.Add(certificate); 
                database.SaveChanges();
            
                certificate = new Certificate( "PMP");            
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("CITP");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("CCNA");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("CISA");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("MCSE");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("Google Ads");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("HubSpot Content Marketing");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("ABA");
                database.Certificate.Add(certificate);
                database.SaveChanges();

                certificate = new Certificate("IPSRT");
                database.Certificate.Add(certificate);
                database.SaveChanges();

            }


            if (!database.Major.Any())
            {

                Major major = new Major("CIS");
                database.Major.Add(major);
                database.SaveChanges();
                
                major = new Major("MIS");
                database.Major.Add(major);
                database.SaveChanges();

                major = new Major("Marketing");
                database.Major.Add(major);
                database.SaveChanges();

            }


            if (!database.PersonalProject.Any())
            
            {
                PersonalProject personalProject = new PersonalProject("Application Building");
                database.PersonalProject.Add(personalProject); 
                database.SaveChanges();

                personalProject = new PersonalProject("Built fuctional website");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

                personalProject = new PersonalProject("Built mobile app");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

                personalProject = new PersonalProject("Built network for small company");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

                personalProject = new PersonalProject("Created a calculator");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

                personalProject = new PersonalProject("Built web scraper");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

                personalProject = new PersonalProject("Created a recipe app");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

                personalProject = new PersonalProject("Created a chess game");
                database.PersonalProject.Add(personalProject);
                database.SaveChanges();

            }


            if(!database.JobHistory.Any())  
            
            
            {
                DateTime jobDateApplied = DateTime.Now.AddDays(-1);
                JobHistory jobHistory = new JobHistory(jobDateApplied, "Tech Assistant", 45000.00);
                database.JobHistory.Add(jobHistory);
                database.SaveChanges();

                jobDateApplied = DateTime.Now.AddDays(-2);
                jobHistory = new JobHistory(jobDateApplied, "Data Analyst", 65000.00);
                database.JobHistory.Add(jobHistory);
                database.SaveChanges();

                jobDateApplied = DateTime.Now.AddDays(-3);
                jobHistory = new JobHistory(jobDateApplied, "Data Scientist", 60000.00);
                database.JobHistory.Add(jobHistory);
                database.SaveChanges();

                jobDateApplied = DateTime.Now.AddDays(-4);
                jobHistory = new JobHistory(jobDateApplied, "Software Engineer", 75000.00);
                database.JobHistory.Add(jobHistory);
                database.SaveChanges();

                jobDateApplied = DateTime.Now.AddDays(-5);
                jobHistory = new JobHistory(jobDateApplied, "Marketing Specialist", 38000.00);
                database.JobHistory.Add(jobHistory);
                database.SaveChanges();

                jobDateApplied = DateTime.Now.AddDays(-6);
                jobHistory = new JobHistory(jobDateApplied, "Digital Marketing Executive", 35000.00);
                database.JobHistory.Add(jobHistory);
                database.SaveChanges();
            } 




            if (!database.StudentCertificate.Any()) 
            
            {
                // Bob
                Student student = database.Student.Where(s => s.UserName == "Test.Bob@test.com").First();
                string studentID = student.Id;

                StudentCertificate studentcertificate = new StudentCertificate(studentID, 1);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 5);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                // Rob
                student = database.Student.Where(s => s.UserName == "Test.Rob@test.com").First();
                studentID = student.Id;

                studentcertificate = new StudentCertificate(studentID, 2);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 3);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                // Jimmy
                student = database.Student.Where(s => s.UserName == "Test.Jimmy@test.com").First();
                studentID = student.Id;

                studentcertificate = new StudentCertificate(studentID, 2);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 4);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                // Tim
                student = database.Student.Where(s => s.UserName == "Test.Tim@test.com").First();
                studentID = student.Id;

                studentcertificate = new StudentCertificate(studentID, 3);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 1);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                // David
                student = database.Student.Where(s => s.UserName == "Test.David@test.com").First();
                studentID = student.Id;

                studentcertificate = new StudentCertificate(studentID, 4);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 2);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                // Andy
                student = database.Student.Where(s => s.UserName == "Test.Andy@test.com").First();
                studentID = student.Id;

                studentcertificate = new StudentCertificate(studentID, 5);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 2);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                // Napoleon
                student = database.Student.Where(s => s.UserName == "Test.Napoleon@test.com").First();
                studentID = student.Id;

                studentcertificate = new StudentCertificate(studentID, 2);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();

                studentcertificate = new StudentCertificate(studentID, 7);
                database.StudentCertificate.Add(studentcertificate);
                database.SaveChanges();



            } 


            if(!database.StudentIntership.Any())
            {

                // Bob
                Student student = database.Student.Where(s => s.UserName == "Test.Bob@test.com").First();
                string studentID = student.Id;

                StudentIntership studentInternship = new StudentIntership(studentID, 1);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 4);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 3);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                // Rob
                student = database.Student.Where(s => s.UserName == "Test.Rob@test.com").First();
                studentID = student.Id;

                studentInternship = new StudentIntership(studentID, 2);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 5);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                // Jimmy
                student = database.Student.Where(s => s.UserName == "Test.Jimmy@test.com").First();
                studentID = student.Id;

                studentInternship = new StudentIntership(studentID, 5);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 6);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();
                studentInternship = new StudentIntership(studentID, 4);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                // Tim
                student = database.Student.Where(s => s.UserName == "Test.Tim@test.com").First();
                studentID = student.Id;

                studentInternship = new StudentIntership(studentID, 3);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 1);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 6);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 4);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                // David
                student = database.Student.Where(s => s.UserName == "Test.David@test.com").First();
                studentID = student.Id;

                studentInternship = new StudentIntership(studentID, 1);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 4);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                // Andy
                student = database.Student.Where(s => s.UserName == "Test.Andy@test.com").First();
                studentID = student.Id;

                studentInternship = new StudentIntership(studentID, 2);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                studentInternship = new StudentIntership(studentID, 5);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

                // Napoleon
                student = database.Student.Where(s => s.UserName == "Test.Napoleon@test.com").First();
                studentID = student.Id;

                studentInternship = new StudentIntership(studentID, 2);
                database.StudentIntership.Add(studentInternship);
                database.SaveChanges();

             





            } 


            if (!database.StudentProject.Any())
            {
                // Bob
                Student student = database.Student.Where(s => s.UserName == "Test.Bob@test.com").First();
                string studentID = student.Id;

                StudentProject studentProject = new StudentProject(studentID, 4);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

                studentProject = new StudentProject(studentID, 5);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();


                // Rob
                student = database.Student.Where(s => s.UserName == "Test.Rob@test.com").First();
                studentID = student.Id;

                studentProject = new StudentProject(studentID, 2);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

                studentProject = new StudentProject(studentID, 3);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

             

                // Jimmy
                student = database.Student.Where(s => s.UserName == "Test.Jimmy@test.com").First();
                studentID = student.Id;

                studentProject = new StudentProject(studentID, 4);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

              

                // Tim
                student = database.Student.Where(s => s.UserName == "Test.Tim@test.com").First();
                studentID = student.Id;

                studentProject = new StudentProject(studentID, 5);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();


                // David
                student = database.Student.Where(s => s.UserName == "Test.David@test.com").First();
                studentID = student.Id;

                studentProject = new StudentProject(studentID, 5);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

                studentProject = new StudentProject(studentID, 2);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

          

                // Andy
                student = database.Student.Where(s => s.UserName == "Test.Andy@test.com").First();
                studentID = student.Id;

                studentProject = new StudentProject(studentID, 2);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

                studentProject = new StudentProject(studentID, 4);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();


                // Napoleon
                student = database.Student.Where(s => s.UserName == "Test.Napoleon@test.com").First();
                studentID = student.Id;

                studentProject = new StudentProject(studentID, 1);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

                studentProject = new StudentProject(studentID, 2);
                database.StudentProject.Add(studentProject);
                database.SaveChanges();

          



            } // FIXED


            if (!database.StudentJobHistory.Any())
            {

                // Bob
                Student student = database.Student.Where(s => s.UserName == "Test.Bob@test.com").First();
                string studentID = student.Id;

                StudentJobHistory studentJobHistory = new StudentJobHistory(studentID, 1);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 4);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 2);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

              

                // Rob
                student = database.Student.Where(s => s.UserName == "Test.Rob@test.com").First();
                studentID = student.Id;

                studentJobHistory = new StudentJobHistory(studentID, 2);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 1);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                // Jimmy
                student = database.Student.Where(s => s.UserName == "Test.Jimmy@test.com").First();
                studentID = student.Id;

                studentJobHistory = new StudentJobHistory(studentID, 4);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 2);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                // Tim
                student = database.Student.Where(s => s.UserName == "Test.Tim@test.com").First();
                studentID = student.Id;

                studentJobHistory = new StudentJobHistory(studentID, 5);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 1);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                // David
                student = database.Student.Where(s => s.UserName == "Test.David@test.com").First();
                studentID = student.Id;

                studentJobHistory = new StudentJobHistory(studentID, 2);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 1);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                // Andy
                student = database.Student.Where(s => s.UserName == "Test.Andy@test.com").First();
                studentID = student.Id;

                studentJobHistory = new StudentJobHistory(studentID, 5);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 4);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                // Napoleon
                student = database.Student.Where(s => s.UserName == "Test.Napoleon@test.com").First();
                studentID = student.Id;

                studentJobHistory = new StudentJobHistory(studentID, 2);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

                studentJobHistory = new StudentJobHistory(studentID, 8);
                database.StudentJobHistory.Add(studentJobHistory);
                database.SaveChanges();

            } // FIXED

            if (!database.StudentMajor.Any())
            {
                // Bob
                Student student = database.Student.Where(s => s.UserName == "Test.Bob@test.com").First();
                string studentID = student.Id;

                StudentMajor studentMajor = new StudentMajor(studentID, 1);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();

                // Rob
                student = database.Student.Where(s => s.UserName == "Test.Rob@test.com").First();
                studentID = student.Id;

                studentMajor = new StudentMajor(studentID, 2);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();

                // Jimmy
                student = database.Student.Where(s => s.UserName == "Test.Jimmy@test.com").First();
                studentID = student.Id;

                studentMajor = new StudentMajor(studentID, 3);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();

                // Tim
                student = database.Student.Where(s => s.UserName == "Test.Tim@test.com").First();
                studentID = student.Id;

                studentMajor = new StudentMajor(studentID, 4);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();

                // David
                student = database.Student.Where(s => s.UserName == "Test.David@test.com").First();
                studentID = student.Id;

                studentMajor = new StudentMajor(studentID, 3);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();

                // Andy
                student = database.Student.Where(s => s.UserName == "Test.Andy@test.com").First();
                studentID = student.Id;

                studentMajor = new StudentMajor(studentID, 2);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();

                // Napoleon
                student = database.Student.Where(s => s.UserName == "Test.Napoleon@test.com").First();
                studentID = student.Id;

                studentMajor = new StudentMajor(studentID, 1);
                database.StudentMajor.Add(studentMajor);
                database.SaveChanges();



            }
        }

        internal static void SeedDatabase()
        {
            throw new NotImplementedException();
        }
    }
}
