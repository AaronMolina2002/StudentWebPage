﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class StudentInternshipRepo : IStudentInternshipRepo
    {
        private ApplicationDbContext database;

        public StudentInternshipRepo(ApplicationDbContext dbcontext)
        {
            this.database = dbcontext;


        }

        public void Add(StudentIntership studentIntership)
        {
            this.database.StudentIntership.Add(studentIntership);
            this.database.SaveChanges();
        }

        public void Delete(StudentIntership studentIntership)
        {
            this.database.StudentIntership.Remove(studentIntership);
            this.database.SaveChanges();
        }

        public StudentIntership FindStudentInternship(int internshipID)
        {
            return this.database.StudentIntership.Where(s => s.StudentIntershipID == internshipID).FirstOrDefault();
        }

        public List< StudentIntership> ListStudentInternships(string studentID)
        {
           return this.database.StudentIntership.Where(s => s.StudentID == studentID).ToList();
        }

    }
}
