﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface ICertificateRepo
    {

        List<Certificate> ListCertificates();

        int AddCertificate(Certificate certificate);

        Certificate FindCertificate(int certID);

        void EditCertificate(Certificate certificate);

        void DeleteCertificate(Certificate certificate);

    }
}
