﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class HumanResourceRepo : IHumanResourceRepo, IMajorRepo
    {

        private ApplicationDbContext database;
        public HumanResourceRepo(ApplicationDbContext context)
        {
            database = context;
        }

        public List<Student> ListAllStudents()
        {
           return database.Student.Include(s => s.StudentInterships).ThenInclude(si => si.Internship).
                Include(s => s.StudentJobHistories).ThenInclude(s => s.JobHistory).
                Include(s=>s.StudentProjects).ThenInclude(s=>s.PersonalProject).
                Include(s=>s.StudentCertificates).ThenInclude(s=>s.Certificate).
                Include(s=>s.StudentMajors).ThenInclude(s=>s.Major).ToList();

        }



        public List<Major> GetAllMajors()
        {
            return this.database.Major.ToList();
        }

        //public Major GetMajorById(int majorId)
        //{
        //    return database.Major.FirstOrDefault(m => m.MajorID == majorId);
        //}

        public int AddMajor(Major major)
        {
            this.database.Major.Add(major);
            this.database.SaveChanges();

            return major.MajorID;
        }

        //public void UpdateMajor(Major major)
        //{
        //    database.Major.Update(major);
        //    database.SaveChanges();
        //}

        //public void DeleteMajor(int majorId)
        //{
        //    var major = database.Major.FirstOrDefault(m => m.MajorID == majorId);
        //    if (major != null)
        //    {
        //        database.Major.Remove(major);
        //        database.SaveChanges();
        //    }
        //}

        public int AddStudentMajor(StudentMajor studentMajor)
        {
            this.database.StudentMajor.Add(studentMajor);
            this.database.SaveChanges();

            return studentMajor.StudentMajorID;
        }
    }
}
