﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IStudentCertificateRepo 
    {
        void Delete(StudentCertificate studentCertificate);

        void Add(StudentCertificate studentCertificate);

        StudentCertificate FindStudentCertificate(int studentCertID);

        List<StudentCertificate> ListStudentCertificates(string studentID);
    }
}
