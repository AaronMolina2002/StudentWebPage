﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IStudentProjectRepo
    {
        List<StudentProject> ListStudentProjects(string studentID);
        void AddProject(StudentProject studentProject);

        void DeleteProject(StudentProject studentProject);

        StudentProject FindStudentProject(int studentProjectID);
    }
}
