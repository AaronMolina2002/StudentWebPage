﻿using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class ProjectRepo : IProjectRepo
    {
        private ApplicationDbContext database;

        public ProjectRepo(ApplicationDbContext dbContext)
        {

            this.database = dbContext;
        }

        public void DeleteProject(PersonalProject project)
        {
            this.database.PersonalProject.Remove(project);
            this.database.SaveChanges();
        }

        public void EditProject(PersonalProject project)
        {
            this.database.PersonalProject.Update(project);
            this.database.SaveChanges();
        }

        public PersonalProject FindProject(int projectID)
        {
            return this.database.PersonalProject.Find(projectID);
        }

        public List<PersonalProject> ListProjects()
        {
            return this.database.PersonalProject.ToList();
        }
    }
}

