﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IStudentInternshipRepo
    {


        

        void Delete(StudentIntership studentIntership);

        void Add(StudentIntership studentIntership);

        StudentIntership FindStudentInternship(int internshipID);

        List<StudentIntership> ListStudentInternships(string studentID);
    }
}
