﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IJobHistoryRepo
    {

        List<JobHistory> ListJobs();

        JobHistory FindJobHistory(int JobId);

        void EditJob(JobHistory jobHistory);

        void DeleteJob(JobHistory jobHistory);
    }
}
