﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IProjectRepo
    {

        PersonalProject FindProject(int projectID);
        void EditProject(PersonalProject project);

        List<PersonalProject> ListProjects();

        void DeleteProject(PersonalProject project);



    }
}
