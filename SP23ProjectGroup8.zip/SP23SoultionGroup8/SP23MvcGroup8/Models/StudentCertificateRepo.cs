﻿using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class StudentCertificateRepo : IStudentCertificateRepo
    {
        private ApplicationDbContext database;

        public StudentCertificateRepo(ApplicationDbContext dbcontext)
        {
            this.database = dbcontext;


        }

        public void Add(StudentCertificate studentCertificate)
        {
            this.database.StudentCertificate.Add(studentCertificate);
            this.database.SaveChanges();
        }

        public void Delete(StudentCertificate studentCertificate)
        {
            this.database.StudentCertificate.Remove(studentCertificate);
            this.database.SaveChanges();
        }

        public StudentCertificate FindStudentCertificate(int studentCertID)
        {
            return this.database.StudentCertificate.Where(s => s.StudentCertificateID == studentCertID).FirstOrDefault();
        }

        public List<StudentCertificate> ListStudentCertificates(string studentID)
        {
            return this.database.StudentCertificate.Where(s => s.StudentID == studentID).ToList();
        }
    }
}
