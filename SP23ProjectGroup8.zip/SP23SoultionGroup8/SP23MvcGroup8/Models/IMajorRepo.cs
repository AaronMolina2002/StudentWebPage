﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IMajorRepo
    {

        // 99% dont need if already implemented in HRRepo?? 
        List<Major> GetAllMajors();
        //Major GetMajorById(int majorId);

        int AddMajor(Major major);

        //void UpdateMajor(Major major);
        //void DeleteMajor(int majorId);

    }
}
