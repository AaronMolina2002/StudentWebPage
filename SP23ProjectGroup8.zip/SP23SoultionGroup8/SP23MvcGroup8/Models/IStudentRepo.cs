﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IStudentRepo 
    {

      //  List<Student> ListAllStudentsResults();

     
        // Might not be set up right, Talk to professor
      //  public int AddStudentEverything();

        public Student FindStudent(string  studentId);

        // WHAT TO RETURN?? List of all ? int of each if added (not created)?? 

    }
}
