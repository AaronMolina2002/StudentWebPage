﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class InternshipRepo : IInternshipRepo
    {
        private ApplicationDbContext database;

        public InternshipRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public List<Internship> ListInternships()
        {
            return this.database.Internship.ToList();
        }

        public Internship FindInternship(int internID)
        {
            return this.database.Internship.Find(internID);
        }

        public void EditInternship(Internship internship)
        {
            this.database.Internship.Update(internship);
            this.database.SaveChanges();
        }

        public void DeleteInternship(Internship internship)
        {
            this.database.Internship.Remove(internship);
            this.database.SaveChanges();
        }
    }
}
