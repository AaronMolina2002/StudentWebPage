﻿using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class JobHistoryRepo : IJobHistoryRepo
    {

        private ApplicationDbContext database;

        public JobHistoryRepo(ApplicationDbContext dbContext)
        {

            this.database = dbContext;
        }

        public void DeleteJob(JobHistory jobHistory)
        {
            this.database.JobHistory.Remove(jobHistory);
            this.database.SaveChanges();
        }

        public void EditJob(JobHistory jobHistory)
        {
            this.database.JobHistory.Update(jobHistory);
            this.database.SaveChanges();
        }

        public JobHistory FindJobHistory(int jobId)
        {
            return this.database.JobHistory.Find(jobId);
        }

        public List<JobHistory> ListJobs()
        {
            return this.database.JobHistory.ToList();
        }
    }
}
