﻿using SP23LibraryGroup8;
using SP23MvcGroup8.Data;
using Microsoft.EntityFrameworkCore;

namespace SP23MvcGroup8.Models
{
    public class StudentJobRepo : IStudentJobRepo
    {
        private ApplicationDbContext database;

        public StudentJobRepo(ApplicationDbContext dbcontext)
        {
            this.database = dbcontext;
        }

        public void AddJob(StudentJobHistory studentJob)
        {
            this.database.StudentJobHistory.Add(studentJob);
            this.database.SaveChanges();
        }

        public void DeleteJob(StudentJobHistory studentJob)
        {
            this.database.StudentJobHistory.Remove(studentJob);
            this.database.SaveChanges();
        }

        public StudentJobHistory FindStudentJob(int jobID)
        {
            return this.database.StudentJobHistory.Where(s => s.StudentJobHistoryID == jobID).FirstOrDefault();

        }

        public List<StudentJobHistory> ListStudentJobs(string studentID)
        {
            return this.database.StudentJobHistory.Where(s => s.StudentID == s.StudentID).ToList();
        }

       
    }
}
