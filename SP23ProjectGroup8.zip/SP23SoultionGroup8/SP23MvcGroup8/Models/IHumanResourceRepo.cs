﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IHumanResourceRepo
    {
        List<Student> ListAllStudents();
        int AddStudentMajor(StudentMajor studentMajor);

    }
}
