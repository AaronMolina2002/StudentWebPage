﻿using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class CertificateRepo : ICertificateRepo
    {
        private ApplicationDbContext database;

        public CertificateRepo(ApplicationDbContext dbContext)
        {

            this.database = dbContext;
        }

        public List<Certificate> ListCertificates()
        {
            return this.database.Certificate.ToList();
        }

        public int AddCertificate(Certificate certificate)
        {
            this.database.Certificate.Add(certificate);
            this.database.SaveChanges();
            return certificate.CertificateID;
        }

        public Certificate FindCertificate(int certID)
        {
            return this.database.Certificate.Find(certID);
        }

        public void EditCertificate(Certificate certificate)
        {
            this.database.Certificate.Update(certificate);
            this.database.SaveChanges();
        }

        public void DeleteCertificate(Certificate certificate)
        {
            this.database.Certificate.Remove(certificate);
            this.database.SaveChanges();
        }
    }
}
