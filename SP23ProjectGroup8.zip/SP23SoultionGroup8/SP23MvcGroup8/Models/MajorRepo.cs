﻿using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class MajorRepo : IMajorRepo
    {
        private ApplicationDbContext database;


        public MajorRepo(ApplicationDbContext dbcontext) 
        {
            
        this.database = dbcontext;
        
        }

        public int AddMajor(Major major)
        {
            this.database.Major.Add(major);
            this.database.SaveChanges();
            return major.MajorID;

        }

        public List<Major> GetAllMajors()
        {
            return this.database.Major.ToList();

        }
    }
}
