﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class StudentProjectRepo : IStudentProjectRepo
    {
        private ApplicationDbContext database;

        public StudentProjectRepo(ApplicationDbContext dbcontext)
        {
            this.database = dbcontext;
        }

        public List<StudentProject> ListStudentProjects(string studentID)
        {
            return this.database.StudentProject.Where(s => s.StudentID == s.StudentID).ToList();
        }

        public void AddProject(StudentProject project)
        {
            this.database.StudentProject.Add(project);
            this.database.SaveChanges();
        }

        public void DeleteProject(StudentProject studentProject)
        {
            this.database.StudentProject.Remove(studentProject);
            this.database.SaveChanges();
        }

        public StudentProject FindStudentProject(int studentProjectID)
        {
           return this.database.StudentProject.Where(s => s.StudentProjectID == studentProjectID).FirstOrDefault();
        }
    }
}
