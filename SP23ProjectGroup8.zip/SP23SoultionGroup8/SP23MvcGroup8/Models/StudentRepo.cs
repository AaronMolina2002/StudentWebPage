﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryGroup8;
using SP23MvcGroup8.Data;

namespace SP23MvcGroup8.Models
{
    public class StudentRepo : IStudentRepo
    {
        private ApplicationDbContext database;

        public StudentRepo(ApplicationDbContext database)
        {

            this.database = database;
        }



        public Student FindStudent(string studentId)
        {

            return this.database.Student.Include(s => s.StudentInterships).ThenInclude(si => si.Internship).
                    Include(s => s.StudentJobHistories).ThenInclude(s => s.JobHistory).
                    Include(s => s.StudentProjects).ThenInclude(s => s.PersonalProject).
                    Include(s => s.StudentCertificates).ThenInclude(s => s.Certificate).
                    Include(s => s.StudentMajors).ThenInclude(s => s.Major).Where(s => s.Id == studentId).FirstOrDefault();
        }
    }
}
