﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IStudentJobRepo
    {
        void DeleteJob(StudentJobHistory studentJob);

        void AddJob(StudentJobHistory studentJob);

        StudentJobHistory FindStudentJob(int jobID);

        List<StudentJobHistory> ListStudentJobs(string studentID);

    }
}
