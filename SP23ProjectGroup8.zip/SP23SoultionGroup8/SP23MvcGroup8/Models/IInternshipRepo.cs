﻿using SP23LibraryGroup8;

namespace SP23MvcGroup8.Models
{
    public interface IInternshipRepo
    {
        List<Internship> ListInternships();
        Internship FindInternship(int internID);
        void EditInternship(Internship internship);
        void DeleteInternship(Internship internship);// Add this method

        //List<StudentIntership> GetStudentInternships(string studentID);

    }
}
